# wifi_deauth_detector

Offline detector for Wi-Fi deauthentication/disassociation spikes in pcap files.
Safe, offline analysis only — does not craft or send any wireless frames.

## Installation

```bash
pip install -e .
# scapy is required to read pcap files
pip install scapy
```

## Usage

```python
from wifi_deauth_detector import generate_report, save_report_json

report = generate_report("captures/my_capture.pcap", window_seconds=10, threshold=6)
save_report_json(report, "reports/my_capture_report.json")
print("Detections:", len(report["detections"]))
```

## Notes
- Use only on captures you are authorized to analyze.
- This project is intended for education and incident-response workflows.
